const Hassan = artifacts.require("Hassan_habibtahir");
module.exports = function (deployer) {
  deployer.deploy(Hassan);
};
